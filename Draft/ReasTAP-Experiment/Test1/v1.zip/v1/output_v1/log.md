Error in table data chunk 6947667: Sample larger than population or is negative
Error in table data chunk 50346: Sample larger than population or is negative
Error in table data chunk 8298326: Sample larger than population or is negative
Error in table data chunk 18984: Sample larger than population or is negative
Error in table data chunk 18984: list index out of range
Error in table data chunk 1905669: Sample larger than population or is negative
Error in table data chunk 1905669: Sample larger than population or is negative
Error in table data chunk 154700: Sample larger than population or is negative
Error in table data chunk 5581115: Sample larger than population or is negative
Error in table data chunk 5581115: Sample larger than population or is negative
Error in table data chunk 184497: Sample larger than population or is negative
Error in table data chunk 10792393: Sample larger than population or is negative
Error in table data chunk 10792393: Sample larger than population or is negative
Error in table data chunk 464912: Sample larger than population or is negative
Error in table data chunk 464912: Sample larger than population or is negative
Error in table data chunk 5510922: Sample larger than population or is negative
Error in table data chunk 10154: Sample larger than population or is negative
